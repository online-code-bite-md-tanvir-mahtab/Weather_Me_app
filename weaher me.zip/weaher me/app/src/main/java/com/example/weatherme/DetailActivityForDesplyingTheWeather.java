package com.example.weatherme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DetailActivityForDesplyingTheWeather extends AppCompatActivity {
    ///now we are gong to crete a variable that will hold the host name of this app..//
    private static final String FORECAST_SHARE_HASTAG = "#Weather Me";
    ///now i am going to store the weather forcast data ..//
    private String mForecast;
    ///now we are going to declare the TextView layout..//
    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_for_desplying_the_weather);
        ///now we are gong to alocate the text View..//
        mTextView = (TextView) findViewById(R.id.tv_weather_desplay);
        Intent intent = getIntent();
        ///now i am going to check if the intent data is null or not ..//
        /*
        if null then it will inter to the loginc that i am going to build..
         */
        if (intent != null){
            ///then we are going to check if the intent data is empty or has a data..//
            if (intent.hasExtra(Intent.EXTRA_TEXT)){
                ///now i am going to get the text..//
                mForecast = intent.getStringExtra(Intent.EXTRA_TEXT);
                mTextView.setText(mForecast);
            }
        }
    }

    private Intent createIntentforSharing() {
        ///now i am goign to build the logic about the share../
        Intent intent = ShareCompat.IntentBuilder.from(this)
                .setType("text/plain")
                .setText(mForecast + FORECAST_SHARE_HASTAG)
                .getIntent();
        return intent;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        ///now i am going to get the menue ....//
        getMenuInflater().inflate(R.menu.detail,menu);
        MenuItem item =menu.findItem(R.id.share_with_others);
        item.setIntent(createIntentforSharing());
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.detai_settings){
            Intent settingIntent = new Intent(this,SettingActrivity.class);
            startActivity(settingIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
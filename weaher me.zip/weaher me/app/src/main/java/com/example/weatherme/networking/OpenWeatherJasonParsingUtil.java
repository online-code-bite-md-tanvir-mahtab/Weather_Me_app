package com.example.weatherme.networking;

import android.content.ContentValues;
import android.content.Context;
import android.util.JsonToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

public class OpenWeatherJasonParsingUtil{
    ///now i am going to create a vertual massage ..//
    private static final String TAG= OpenWeatherJasonParsingUtil.class.getSimpleName();
    /*
    now for the simple jason data we are going to have to parse the data..
     so we are gong to do fist we are gong to create a class..
     */
    public static String[] getSupportJasonParsing(Context context , String thisWeatherData) throws JSONException {

        ///for the for the code 200..//
        final String OWN_JASON_CODE = "cod";
        final  String OWN_JASON_LIST = "list";

        ///for the array and object..//
        final String OWN_JASON_TEMP = "temp";
        final String OWN_JASON_MAX = "max";
        final String OWN_JASON_MIN = "min";

        ///now for the second part..//
        final String OWN_JASON_WEATHER = "weather";
        final String OWN_JASON_MMAIN = "main";

        ///now to store the weather data we are going to create a array stringg../
        final String[] weatherBox;

        //now i am going to enter the jason object by persing it..//
        ///with the help of JasonObject..//
        JSONObject forecastJason = new JSONObject(thisWeatherData);
        if (forecastJason.has(OWN_JASON_CODE)){
            int errorCode = forecastJason.getInt(OWN_JASON_CODE);
            switch (errorCode){
                case HttpURLConnection.HTTP_OK:
                    break;
                case HttpURLConnection.HTTP_NOT_FOUND:
                    break;
                default:
                    return null;
            }
        }
        ///now i am going to parse the array form the jason..///
        JSONArray weatherJsonArray = forecastJason.getJSONArray(OWN_JASON_LIST);

        ///now i am going to see the length of the weather data.//
        weatherBox = new String[weatherJsonArray.length()];
        long localDate = System.currentTimeMillis();
        long utcDate = DateAndTime.getUTCDAteFromLocal(localDate);
        long startDay = DateAndTime.normalizedDate(utcDate);
        ///now we are goning to parse the other value or key from the json..//
        ///so for that we will be using the for loop that will hold the
        for (int i =0; i<weatherJsonArray.length(); i++){
            String highAndLow;
            String date;
            ///we are going to decalre the max and min of the temparature in the json..//
            long dateAndTime;
            double highTemparaturea;
            double lowTemparatures;
            String description;

            ///now we are goign to get  the json object from the json array..//
            JSONObject weatherJsonObject = weatherJsonArray.getJSONObject(i);
            dateAndTime = startDay + DateAndTime.DAY_IN_MILLIS * i;
             date = DateAndTime.getFrienlyDateString(context,dateAndTime,false);
            ///now i am agin going to parse the array json from the json object..//
            JSONObject weatherUpdate = weatherJsonObject.getJSONArray(OWN_JASON_WEATHER)
                    .getJSONObject(0);
            description = weatherUpdate.getString(OWN_JASON_MMAIN);
            ///now we are going to parse the data  of the temparature json objecty...//
            JSONObject tempratureJsonObject = weatherJsonObject.getJSONObject(OWN_JASON_TEMP);
            //now we are going to initialize the keyword....///
            highTemparaturea = tempratureJsonObject.getDouble(OWN_JASON_MAX);
            lowTemparatures = tempratureJsonObject.getDouble(OWN_JASON_MIN);
            highAndLow = Temparature.highAndLow(context,highTemparaturea,lowTemparatures);
            weatherBox[i] = date + "-" + description + "-" + highAndLow;
            
        }

        return weatherBox;
    }
    public ContentValues[] getFulDataFromJason(Context context,String forecastJasonStr){
        return null;
    }
}

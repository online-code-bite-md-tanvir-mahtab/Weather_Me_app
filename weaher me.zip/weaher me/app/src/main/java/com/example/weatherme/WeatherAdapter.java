package com.example.weatherme;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weatherme.networking.DateAndTime;
import com.example.weatherme.networking.Temparature;

import org.w3c.dom.Text;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.WeatherViewHolder> {
    ///nwo i am going to create the context for the class..//
    private final Context mContext;
    //now i am gogn to define the interface..//
    final private WeatherAdapterOnClickHendaling mClickHendaler;
    /*
    now i am goig to create an interface
    that will contain an mathod that is for thed onclick handeling
    and the parameter will be String data
     */
    public interface WeatherAdapterOnClickHendaling{
        void onLoadFinished(Loader<Cursor> loader, String[] data);
        ///now iam  giong to declare the void mathod../
        void onClick(String weatherClick);
    }
    ///now i ma going to have a cursor..//
    private Cursor mCursor;

    public WeatherAdapter(Context context,WeatherAdapterOnClickHendaling onClickHendaling) {
        mClickHendaler = onClickHendaling;
        mContext = context;
    }

    public class WeatherViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ///now i am going to create a textView..//
        TextView mTextview;
        public WeatherViewHolder(@NonNull View itemView) {
            super(itemView);
            mTextview = (TextView) itemView.findViewById(R.id.tv_weather_data);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            String weatherForDAy = mTextview.getText().toString();
            mClickHendaler.onClick(weatherForDAy);
            view.setOnClickListener(this);
        }
    }
    @NonNull
    @Override
    public WeatherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ///now i am going to inflate the layout..//
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new WeatherViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeatherViewHolder holder, int position) {
        ////now i am going to take my cursor position to the first or next....//
        mCursor.moveToPosition(position);
        //now for the weather..//
        long dateMills = mCursor.getLong(0);
        String datestring = DateAndTime.getFrienlyDateString(mContext,dateMills,false);
        int weatherid = mCursor.getInt(3);
        String description = DateAndTime.getStringForWeatherContdition(mContext,weatherid);
        ///now i am going to store the
        double highInCalsius =mCursor.getDouble(1);
        double lowInCalsius = mCursor.getDouble(2);
        ///now i am going to get the high and low temparature..//
        String highAndLowInTeparature = Temparature.highAndLow(mContext,highInCalsius,lowInCalsius);
        String weatherSummerry = datestring + "-" + description + "-" + highAndLowInTeparature;
        holder.mTextview.setText(weatherSummerry);

    }

    @Override
    public int getItemCount() {
        ///we are gong to check if the data is null or not..//
        if (mCursor == null) return  0;
        return mCursor.getCount();
    }
    void mCursorSwap(Cursor cursor){
        mCursor = cursor;
        notifyDataSetChanged();
    }
}

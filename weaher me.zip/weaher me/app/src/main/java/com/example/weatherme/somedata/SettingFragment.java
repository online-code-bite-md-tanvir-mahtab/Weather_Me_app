package com.example.weatherme.somedata;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.preference.CheckBoxPreference;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceScreen;

import com.example.weatherme.R;

import java.util.List;

public class SettingFragment extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener{
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        ///now i am going to add the preference screen from the xml screen..//
        addPreferencesFromResource(R.xml.preference_screen);
        SharedPreferences sharedPreferences = getPreferenceScreen().getSharedPreferences();
        PreferenceScreen preferenceScreen = getPreferenceScreen();
        int prefCount = preferenceScreen.getPreferenceCount();
        for (int i= 0;i<prefCount;i++){
            ///now i am going to havce the preference ..//
            Preference preference = preferenceScreen.getPreference(i);
            if (!(preference instanceof CheckBoxPreference)){
                ///now  i am going to have the vlue key..
                String value = sharedPreferences.getString(preference.getKey(),"");
                ///now i am goign to set the preference sumarry...//
                setSharedPreferenceSummery(preference,value);
            }
        }
    }

    private void setSharedPreferenceSummery(Preference preference, String value) {
        String stringValue =value.toString();
        String key = preference.getKey();
        if (preference instanceof ListPreference){
            ListPreference listPreference = (ListPreference) preference;
            int indexKey =listPreference.findIndexOfValue(stringValue);
            if (indexKey >= 0){
                preference.setSummary(listPreference.getEntries()[indexKey]);
            }
        }else{
            preference.setSummary(stringValue);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        Preference preference = findPreference(s);
        if (null != preference){
            if (!(preference instanceof CheckBoxPreference)){
                setSharedPreferenceSummery(preference,sharedPreferences.getString(s,""));
            }
        }

    }
}

package com.example.weatherme;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.AsyncTaskLoader;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.icu.util.Calendar;
import android.media.tv.TvContract;
import android.net.Uri;
import android.net.wifi.WifiEnterpriseConfig;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.system.StructTimespec;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.weatherme.database.WeatherDataBaseContract;
import com.example.weatherme.database.WeatherFakeData;
import com.example.weatherme.networking.DateAndTime;
import com.example.weatherme.networking.NetworkUtil;
import com.example.weatherme.networking.OpenWeatherJasonParsingUtil;
import com.example.weatherme.somedata.MyOtherData;

import org.json.JSONException;
import org.w3c.dom.Text;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements
        ///now i ma implementing the loder manaager to handle the setuation ...///
        LoaderManager.LoaderCallbacks<Cursor>, WeatherAdapter.WeatherAdapterOnClickHendaling {
    /*
  now i am going to crate a variable that will contain all the desigre value
  that i went to show in the detail activity and main activity.
   */
    public static final String[] MAIN_FORCAST_PROJECTION = {
            WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_DATE,///for the date of the location..///
            WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_MAX_TEMP, ///fot the maximum temparature..//
            WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_MIN_TEMP,
            WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_WEATHER_ID
    };
    ///now i am going to create a loader id..//
    private static final int LOADER_ID =44;
    public static final String TAG  = MainActivity.class.getSimpleName();
    ///now i am goign to create the adapter..//
    private WeatherAdapter mAdapter;
    private RecyclerView mRecyclerView;
    ///for the loading indicator..//
    private ProgressBar mLoadingIndecator;
    ///now i am going to have the positon..//
    private int mPosition = RecyclerView.NO_POSITION;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ////now i am going to call the fake weather data../
        WeatherFakeData.setFakedata(this);
        ///now  i am gogn to locate the layout every view..//
        mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        ///fixed the size of the recyclerview..//
        mRecyclerView.setHasFixedSize(true);
        ///now i have to use the linearlayoutmanager..//
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(layoutManager);
        mAdapter = new WeatherAdapter(this ,this);
        mRecyclerView.setAdapter(mAdapter);
        mLoadingIndecator = (ProgressBar) findViewById(R.id.pb_loading_indicator);
        ///now i am going to load the weather data....//
        getSupportLoaderManager().initLoader(LOADER_ID,null,this);
        showLoading();
    }

    private void showWeatherDataView(){
        mLoadingIndecator.setVisibility(View.INVISIBLE);
        mRecyclerView.setVisibility(View.VISIBLE);
    }
    private void showLoading(){
        mLoadingIndecator.setVisibility(View.VISIBLE);
        mRecyclerView.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, String[] data) {

    }

    @Override
    public void onClick(String weatherClick) {
        ///now i am going to do an activity intent ..//
        Intent detailIntent = new Intent(MainActivity.this,DetailActivityForDesplyingTheWeather.class);
        //now i am gong to add the text to the detail desplay..
        detailIntent.putExtra(Intent.EXTRA_TEXT,weatherClick);
        startActivity(detailIntent);

    }
    public void showInMap(){
        ///now i am gogn to give a defaoult massage..//
        String location = "9000,Khulna";
        Uri geoLocation = Uri.parse("geo:0.0 ? q ="+location);
        Intent newIntent = new Intent(Intent.ACTION_VIEW);
        newIntent.setData(geoLocation);
        if (newIntent.resolveActivity(getPackageManager())!= null){
            startActivity(newIntent);
        }
    }
    ///now i am goign to create a menue ..//

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        ///now i am gogn to have a menue inflater..//
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.forecast,menu);
        return true;
    }
    ///now we need to set the logic to hendle the menue click../

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        ///now i am going to get the item id..//
        int id = item.getItemId();
        ///now we are gong to check the item is mathcheds with the
        if (id == R.id.show_as_reference){
            getSupportLoaderManager().initLoader(LOADER_ID,null,this);
            return true;
        }
        if (id == R.id.show_of_the_map){
            Toast.makeText(this,"you have clicked to show the map",Toast.LENGTH_SHORT).show();
            showInMap();
            return true;
        }
        if (id == R.id.settings){
            Intent settingIntent = new Intent(this,SettingActrivity.class);
            startActivity(settingIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        switch (id){
            case LOADER_ID:
                ////now fro the query url..//
                Uri forcastUri = WeatherDataBaseContract.WeatherDataBaseEntry.CONTENT_URI;
                ///now for the sort order for adding the list by the date..//
                String sortOrder = WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_DATE + "ASC";
                ///now for the selection..//
                String selection = WeatherDataBaseContract.WeatherDataBaseEntry.getSqlSelectForTodywords();

                return  new CursorLoader(this,
                        forcastUri,
                        MAIN_FORCAST_PROJECTION,
                        selection,
                        null,
                        sortOrder);
            default:
                throw new RuntimeException("Loader not implemented: " + id);
        }
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        ///now i am going to swap the data..//
        mAdapter.mCursorSwap(data);
        ///now going to check if the position is matched to the
        if (mPosition == RecyclerView.NO_POSITION) mPosition = 0;
        ///now we are going to scrool the veiew..//
        mRecyclerView.smoothScrollToPosition(mPosition);
        if (data.getCount() != 0)showWeatherDataView();
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {
        mAdapter.mCursorSwap(null);

    }
}
package com.example.weatherme.database;

import android.content.ContentValues;
import android.content.Context;

import com.example.weatherme.networking.DateAndTime;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class WeatherFakeData {
    private static int[] weatherIds ={200,300,500,711,900,962};
    private static ContentValues createTestWeatherContentValue(long date){
        ContentValues contentValues = new ContentValues();
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_DATE , date);
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_DEGREES, Math.random()*2);
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_HUMIDITY, Math.random()*100);
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_PRESSURE, 870 + Math.random()*100);
        int maxTemp = (int)(Math.random()*100);
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_MAX_TEMP,maxTemp);
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_MIN_TEMP, maxTemp-(int)(Math.random()*10));
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_WIND_SPEED,Math.random()*10);
        contentValues.put(WeatherDataBaseContract.WeatherDataBaseEntry.COLUMN_WEATHER_ID, weatherIds[(int)(Math.random()*10)%5]);
        return contentValues;
    }
    public  static void setFakedata(Context context){
        //Get today's normalized date
        long today = DateAndTime.normalizedDate(System.currentTimeMillis());
        List<ContentValues> fakeValues = new ArrayList<ContentValues>();
        //loop over 7 days starting today onwards
        for(int i=0; i<7; i++) {
            fakeValues.add(WeatherFakeData.createTestWeatherContentValue(today + TimeUnit.DAYS.toMillis(i)));
        }
        // Bulk Insert our new weather data into Sunshine's Database
        context.getContentResolver().bulkInsert(
                WeatherDataBaseContract.WeatherDataBaseEntry.CONTENT_URI,
                fakeValues.toArray(new ContentValues[7]));
    }
}

package com.example.weatherme.networking;

import android.content.Intent;
import android.database.CursorIndexOutOfBoundsException;
import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class NetworkUtil {
    /*
    in this calss we are going to create some variable and mathod that will help
    us to connect to the internet and parse the internet data from the jason
     */
    /// now i am going to show a simple massage ..//
    private static final String TAG_MASSAGE = NetworkUtil.class.getSimpleName();
    ///now i am going to have to uril ..//
    private static final String DYNAMYIC_WEATHER_URL =  "https://andfun-weather.udacity.com/weather";
    ///now for the second its a static weather..//
    private static final String STATIC_WEATHER_URL = "https://andfun-weather.udacity.com/staticweather";

    ///now i am going to have a base weather data url..//
    private static final String BASE_WEATHER_URL = STATIC_WEATHER_URL;

    /*
    now we need the json key of the url that we have taken..
     */
    ///for the format type..//
    private static final String format = "json";
    ///for the marric type ...//
    private static final String units = "metric";
    ////now for the id..//
    private static final int numDays = 14;

    ///now for the url quer4y ..//
    final  static String QUERY_PARAM = "q";
    final  static String LAT_PARAM = "lat";
    final  static String LON_PARAM = "lon";
    final static String FORMAT_PARAM = "mode";
    final static String UNITS_PARAM = "units";
    final static String FINAL_PARAMS = "cnt";

    public static URL buildUrl(String loactionQuary){
        ///to get the url we need to use the uri..//
        Uri buildUri = Uri.parse(BASE_WEATHER_URL)
                .buildUpon()
                .appendQueryParameter(QUERY_PARAM,loactionQuary)
                .appendQueryParameter(FORMAT_PARAM,format)
                .appendQueryParameter(UNITS_PARAM, units)
                .appendQueryParameter(FINAL_PARAMS, Integer.toString(numDays))
                .build();
        ///now i am going to create the URL object...//
        URL newURL = null;
        try{
            newURL = new URL(buildUri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return newURL;
    }
    public static URL buildUrl(Double lat, Double lon){
        return  null;
    }
    public static String getHttpResponseFromUrl(URL url) throws IOException {
        ////nwo i am going to open an request form url..//
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try{
            ///now i am gong to get the input stream..//
            InputStream inputStream = urlConnection.getInputStream();
            ///now i am going to create the scanner object../
            Scanner scanner = new Scanner(inputStream);
            scanner.useDelimiter("\\A");
            ///nwo i am going to check if it has any data or not..//
            boolean hasNext = scanner.hasNext();
            if (hasNext){
                return scanner.next();
            }else {
                return  null;
            }
        }finally {
            urlConnection.disconnect();
        }
    }
}

package com.example.weatherme.somedata;

import android.content.Context;

public class MyOtherData {
    ///now i have created a city name that will help me to colact the data
    private static final String PREF_CITY_NAME = "city_name";
    /*
    now i am going to create a variable that will hold the lantitude and langitude..//
     */
    private static final String PREF_COORED_LAT = "coord_lat";
    private static final String PREF_COORED_LONG = "coord_long";

    /*
    now i am going to set a defaoult weather value...
     */
    private static final String  DEFAULT_WEATHER_LOCATION = "9000,BD";
    private static final double[] DEFAULT_WEATHER_CORDINATE = {37.4284, 122.0724};

    ///now i am gong to take a defaoult location name..//
    private static final String DEFAOULT_MAP_LOCATION =
            "12,9000,khulna,boyra,bangladesh";
    static public void setLocationDetails(Context c,String locationSettings,double lat,double lon){
        /*
        for the future to do
         */
    }
    static public void setLocation(Context c,String locationSettings,double lat,double lon){
        /*
        i will do it in the future..
         */
    }

    /**
     * now we are gong to check the data is matric or not
     * @param context its  locate the maing class
     * @return we will retur the data as atrue
     */
    public static boolean inMatric(Context context){
        return  true;
    }

    public static String getPreferenceWeatherLocation(Context context){
        /**
         * i will do this in the future.
         */
        return getDefaultWeatherLocation();
    }
    public static double[] getLocationCordinates(Context context){
        return getDefaultWeatherCordinate();
    }
    public static boolean isLocationLatAndLanAvailable(Context context){
        return false;
    }

    private static String getDefaultWeatherLocation(){
        return DEFAULT_WEATHER_LOCATION;
    }
    public static double[] getDefaultWeatherCordinate(){
        return DEFAULT_WEATHER_CORDINATE;
    }
}

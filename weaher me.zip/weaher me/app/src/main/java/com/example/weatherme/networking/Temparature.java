package com.example.weatherme.networking;

import android.content.Context;

import com.example.weatherme.R;
import com.example.weatherme.somedata.MyOtherData;

public class Temparature {
    ///for the tagg massage..//
    private static final String TAG = Temparature.class.getSimpleName();
    /*
    now i am going to create a mathod that will make the cacius to farhenhieght
     */
    private static double calciousToFarhenhight(double temparatureIntoCalcules){
        ///now i am going to create the calculator for the temparature..//
        double temparatureFarenhit = (temparatureIntoCalcules * 1.8) + 32;
        return temparatureFarenhit;
    }

    /**
     *
     * @param context
     * @param temparature
     * @return
     */
    public static String formateTemperature(Context context, double temparature){
        int temperatureFormatResourceId = R.string.format_temperature_celsius;
        ///now i am goning to check the data is matric or not..//
        if (!MyOtherData.inMatric(context)){
            //now i am going to store the calcious mathmatical term to the parameter ..//
            temparature = calciousToFarhenhight(temparature);
            temperatureFormatResourceId = R.string.format_temperature_fahrenheit;
        }
        return String.format(context.getString(temperatureFormatResourceId),temparature);
    }
    public static String highAndLow(Context context, double high, double low){
        long roundInHigh = Math.round(high);
        long roundInLow = Math.round(low);
        ///now i am going to call the
        String formattedHigh = formateTemperature(context,roundInHigh);
        String formattedLow = formateTemperature(context,roundInLow);
        String highandlow = formattedHigh + "/" + formattedLow;
        return highandlow;
    }

}

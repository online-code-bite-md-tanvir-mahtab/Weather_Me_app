package com.example.weatherme.networking;

import android.content.Context;
import android.text.format.DateUtils;

import com.example.weatherme.R;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

//now i am going to make the class as a final that 2will not be changable
//unless i meke it not final...//
public final class DateAndTime {

    /**
     * then i am gjoing to use the math operation of how to convert the time into the date..
     */
    public static final int SECOND_IN_MILLIS = 1000;
    public static final int MINUTE_IN_MILLIS =  SECOND_IN_MILLIS  * 60;
    public static final int HOUR_IN_MILLIS = MINUTE_IN_MILLIS * 60;
    public static final int DAY_IN_MILLIS  = HOUR_IN_MILLIS * 24;

    /*
    now we are going to count the day for the weather..
     */
    public static long getDayNumber(long date){
        TimeZone timeZone = TimeZone.getDefault();
        ///now we are going to ge the time as a offset../
        long gmtOffset = timeZone.getOffset(date);
        return (date + gmtOffset)/ DAY_IN_MILLIS;

    }
    /**
     * now i am going to normalize the date
     * @return
     */
    public static long normalizedDate(long date){
        long retValNew = date / DAY_IN_MILLIS * DAY_IN_MILLIS;
        return retValNew;
    }
    public static boolean isDateNormalized(long millisecond){
        boolean isNormalized = false;
        if (millisecond % DAY_IN_MILLIS == 0){
            isNormalized = true;
        }
        return isNormalized;
    }

    /**
     *
     * @param utcDate
     * @return
     */
    public static long getLocalDateFromUTC(long utcDate){
        TimeZone timeZone = TimeZone.getDefault();
        long getOffset = timeZone.getOffset(utcDate);
        return  utcDate - getOffset;
    }

    /**
     *
     * @param localDAte
     * @return
     */
    public static long getUTCDAteFromLocal(long localDAte){
        TimeZone timeZone = TimeZone.getDefault();
        long gmtOffset = timeZone.getOffset(localDAte);
        return  localDAte + gmtOffset;
    }

    public static String getFrienlyDateString(Context context, long dateInMills, boolean showFullDate){
        ///for the local date../
        long localdate = getLocalDateFromUTC(dateInMills);
        long dayNumber = getDayNumber(dateInMills);
        long currentDayNumber = getDayNumber(System.currentTimeMillis());
        if (dayNumber == currentDayNumber || showFullDate){
            String dayNam = getDayName(context,localdate);
            String readableDate = getReadableDateString(context,localdate);
            if (dayNumber - currentDayNumber < 2){
                String lcalizedDayName = new SimpleDateFormat("EEEE").format(localdate);
                return readableDate.replace(lcalizedDayName,dayNam);
            }else {
                return readableDate;
            }
        }else if (dayNumber < currentDayNumber + 7){
            return getDayName(context,localdate);
        }else {
            int flags = DateUtils.FORMAT_SHOW_DATE
                    | DateUtils.FORMAT_NO_YEAR
                    | DateUtils.FORMAT_ABBREV_ALL
                    | DateUtils.FORMAT_SHOW_WEEKDAY;
            return DateUtils.formatDateTime(context,localdate,flags);
        }
    }
    private static String getReadableDateString(Context context , long  timeInMillis){
        int flags = DateUtils.FORMAT_SHOW_DATE
                | DateUtils.FORMAT_NO_YEAR
                | DateUtils.FORMAT_SHOW_WEEKDAY;
        return DateUtils.formatDateTime(context,timeInMillis,flags);
    }

    private static String getDayName(Context context, long dateInMills) {
        ///now i am going to calll the day number..//
        long dayNumber = getDayNumber(dateInMills);
        //now i need the current date time so we are gong to do this../
        long currentDayNumber = getDayNumber(System.currentTimeMillis());
        if (dayNumber == currentDayNumber) {
            return context.getString(R.string.today);
        } else if (dayNumber == currentDayNumber + 1) {
            return context.getString(R.string.tomorrow);
        } else {
            SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE");
            return dateFormat.format(dateInMills);
        }
    }
    public static String getStringForWeatherContdition(Context context, int weatherId){
        int stringId ;
        if (weatherId >= 200 && weatherId <= 232){
            weatherId = R.string.condition_2xx;
        }else if (weatherId >= 300 && weatherId <= 321){
            weatherId = R.string.condition_3xx;
        }else switch (weatherId) {
            case 500:
                stringId = R.string.condition_500;
                break;
            case 501:
                stringId = R.string.condition_501;
                break;
            case 502:
                stringId = R.string.condition_502;
                break;
            case 503:
                stringId = R.string.condition_503;
                break;
            case 504:
                stringId = R.string.condition_504;
                break;
            case 511:
                stringId = R.string.condition_511;
                break;
            case 520:
                stringId = R.string.condition_520;
                break;
            case 531:
                stringId = R.string.condition_531;
                break;
            case 600:
                stringId = R.string.condition_600;
                break;
            case 601:
                stringId = R.string.condition_601;
                break;
            case 602:
                stringId = R.string.condition_602;
                break;
            case 611:
                stringId = R.string.condition_611;
                break;
            case 612:
                stringId = R.string.condition_612;
                break;
            case 615:
                stringId = R.string.condition_615;
                break;
            case 616:
                stringId = R.string.condition_616;
                break;
            case 620:
                stringId = R.string.condition_620;
                break;
            case 621:
                stringId = R.string.condition_621;
                break;
            case 622:
                stringId = R.string.condition_622;
                break;
            case 701:
                stringId = R.string.condition_701;
                break;
            case 711:
                stringId = R.string.condition_711;
                break;
            case 721:
                stringId = R.string.condition_721;
                break;
            case 731:
                stringId = R.string.condition_731;
                break;
            case 741:
                stringId = R.string.condition_741;
                break;
            case 751:
                stringId = R.string.condition_751;
                break;
            case 761:
                stringId = R.string.condition_761;
                break;
            case 762:
                stringId = R.string.condition_762;
                break;
            case 771:
                stringId = R.string.condition_771;
                break;
            case 781:
                stringId = R.string.condition_781;
                break;
            case 800:
                stringId = R.string.condition_800;
                break;
            case 801:
                stringId = R.string.condition_801;
                break;
            case 802:
                stringId = R.string.condition_802;
                break;
            case 803:
                stringId = R.string.condition_803;
                break;
            case 804:
                stringId = R.string.condition_804;
                break;
            case 900:
                stringId = R.string.condition_900;
                break;
            case 901:
                stringId = R.string.condition_901;
                break;
            case 902:
                stringId = R.string.condition_902;
                break;
            case 903:
                stringId = R.string.condition_903;
                break;
            case 904:
                stringId = R.string.condition_904;
                break;
            case 905:
                stringId = R.string.condition_905;
                break;
            case 906:
                stringId = R.string.condition_906;
                break;
            case 951:
                stringId = R.string.condition_951;
                break;
            case 952:
                stringId = R.string.condition_952;
                break;
            case 953:
                stringId = R.string.condition_953;
                break;
            case 954:
                stringId = R.string.condition_954;
                break;
            case 955:
                stringId = R.string.condition_955;
                break;
            case 956:
                stringId = R.string.condition_956;
                break;
            case 957:
                stringId = R.string.condition_957;
                break;
            case 958:
                stringId = R.string.condition_958;
                break;
            case 959:
                stringId = R.string.condition_959;
                break;
            case 960:
                stringId = R.string.condition_960;
                break;
            case 961:
                stringId = R.string.condition_961;
                break;
            case 962:
                stringId = R.string.condition_962;
                break;
        }
        return  context.getString(weatherId);
    }
}
